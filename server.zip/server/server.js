const express = require('express');
const http = require('http');
const path = require('path');
const socketIO = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIO(server);

const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, '../')));

let rooms = {};

io.on('connection', (socket) => {
  console.log(`User connected: ${socket.id}`);

  socket.on('joinRoom', (roomId) => {
    socket.join(roomId);
    console.log(`User ${socket.id} joined room ${roomId}`);

    if (!rooms[roomId]) {
      rooms[roomId] = {
        players: [socket.id],
        board: Array(9).fill(null),
        currentTurn: socket.id,
        symbols: { [socket.id]: 'X' },
      };
    } else {
      if (rooms[roomId].players.length < 2) {
        rooms[roomId].players.push(socket.id);
        rooms[roomId].symbols[socket.id] = 'O';
        io.to(roomId).emit('startGame', {
          symbols: rooms[roomId].symbols,
          currentTurn: rooms[roomId].currentTurn,
        });
      } else {
        socket.emit('roomFull');
      }
    }
  });

  socket.on('makeMove', ({ roomId, index }) => {
    const room = rooms[roomId];
    if (!room || socket.id !== room.currentTurn || room.board[index]) return;

    const symbol = room.symbols[socket.id];
    room.board[index] = symbol;

    const winner = checkWinner(room.board);
    if (winner) {
      io.to(roomId).emit('gameOver', { winner: symbol, board: room.board });
      delete rooms[roomId];
    } else if (room.board.every(cell => cell)) {
      io.to(roomId).emit('gameOver', { winner: null, board: room.board });
      delete rooms[roomId];
    } else {
      room.currentTurn = room.players.find(id => id !== socket.id);
      io.to(roomId).emit('updateBoard', {
        board: room.board,
        currentTurn: room.currentTurn,
      });
    }
  });

  socket.on('disconnect', () => {
    console.log(`User disconnected: ${socket.id}`);
    for (const roomId in rooms) {
      const room = rooms[roomId];
      if (room.players.includes(socket.id)) {
        io.to(roomId).emit('playerLeft');
        delete rooms[roomId];
        break;
      }
    }
  });
});

server.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

function checkWinner(board) {
  const winPatterns = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8],
    [0, 3, 6], [1, 4, 7], [2, 5, 8],
    [0, 4, 8], [2, 4, 6],
  ];

  for (const [a, b, c] of winPatterns) {
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return board[a];
    }
  }
  return null;
}
